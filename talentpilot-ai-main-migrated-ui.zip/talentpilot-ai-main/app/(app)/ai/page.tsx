"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

export default function AIPage() {
  const router = useRouter();

  const [type, setType] = useState("job_description");
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      // Le layout (AppShell) protège déjà /dashboard et sections.
      // Ici on garde seulement la récupération de token au moment de l'appel.
      await supabase.auth.getSession();
    })();
  }, [router]);

  const run = async () => {
    setErr("");
    setOutput("");
    setBusy(true);

    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;

    if (!token) {
      setBusy(false);
      router.push("/login");
      return;
    }

    try {
      const res = await fetch("/api/ai/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ type, input }),
      });

      const json = await res.json();
      setBusy(false);

      if (!res.ok) {
        setErr(json?.error ?? "Erreur inconnue");
        return;
      }

      setOutput(json.output ?? "");
      if (json?.error) setErr(json.error); // cas log failed
    } catch (e: any) {
      setBusy(false);
      setErr(e?.message ?? "Erreur réseau");
    }
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Génération AI</h1>
          <p className="text-slate-500 mt-1">Générez des contenus RH prêts à utiliser (Québec / Canada).</p>
        </div>
        <button
          onClick={run}
          disabled={busy || !input.trim()}
          className="gradient-bg text-white font-bold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {busy ? "Génération..." : "Générer"}
        </button>
      </div>

      <div className="bg-white/80 border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="text-sm text-slate-600 font-medium">Type</div>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none min-w-[220px]"
          >
            <option value="job_description">Offre d’emploi</option>
            <option value="outreach">Message de prospection</option>
            <option value="interview">Questions d’entrevue</option>
          </select>
        </div>

        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Collez ici les informations (poste, stack, seniorité, ton, contexte, etc.)"
          rows={7}
          className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white/90 outline-none"
        />

        {err ? <div className="text-sm font-semibold text-red-600">❌ {err}</div> : null}

        <textarea
          value={output}
          readOnly
          placeholder="Résultat..."
          rows={12}
          className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white/70 outline-none"
        />
      </div>
    </div>
  );
}