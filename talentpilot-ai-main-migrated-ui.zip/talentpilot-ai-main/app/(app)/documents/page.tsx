"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type DocRow = {
  id: string;
  candidate_id: string;
  file_url: string;
  file_type: string;
  created_at: string;
};

export default function DocumentsPage() {
  const [items, setItems] = useState<DocRow[]>([]);
  const [candidateId, setCandidateId] = useState("");
  const [fileType, setFileType] = useState("CV");
  const [file, setFile] = useState<File | null>(null);

  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");

  useEffect(() => {
    (async () => {
      await refresh();
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refresh = async () => {
    setErr("");
    const { data, error } = await supabase
      .from("documents")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      setErr(error.message);
      setItems([]);
      return;
    }
    setItems((data ?? []) as DocRow[]);
  };

  const upload = async () => {
    setErr("");
    setOk("");

    if (!candidateId.trim()) {
      setErr("Candidate ID est requis.");
      return;
    }
    if (!file) {
      setErr("Veuillez sélectionner un fichier.");
      return;
    }

    setBusy(true);

    try {
      const ext = (file.name.split(".").pop() || "bin").toLowerCase();
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `org/${candidateId.trim()}/${Date.now()}_${safeName}`;

      // 1) Upload storage
      const { error: upErr } = await supabase.storage.from("documents").upload(path, file, {
        upsert: false,
        contentType: file.type || undefined,
      });

      if (upErr) {
        setBusy(false);
        setErr(upErr.message);
        return;
      }

      // 2) URL signée (optionnel pour ouvrir en cliquant)
      const { data: signed, error: signErr } = await supabase.storage
        .from("documents")
        .createSignedUrl(path, 60 * 60); // 1h

      if (signErr) {
        // pas bloquant
      }

      // 3) Insert table documents (on garde path, et on stocke aussi l’url signée pour MVP)
      const { data: row, error: insErr } = await supabase
        .from("documents")
        .insert({
          candidate_id: candidateId.trim(),
          file_type: fileType,
          file_url: signed?.signedUrl ?? path,
        })
        .select()
        .single();

      if (insErr) {
        setBusy(false);
        setErr(insErr.message);
        return;
      }

      setItems([row as DocRow, ...items]);
      setFile(null);
      setOk("Document ajouté avec succès.");
      setBusy(false);
    } catch (e: any) {
      setBusy(false);
      setErr(e?.message ?? "Erreur upload");
    }
  };

  const openDoc = async (doc: DocRow) => {
    setErr("");
    // Si file_url est déjà une URL signée (MVP), on ouvre direct.
    if (doc.file_url.startsWith("http")) {
      window.open(doc.file_url, "_blank");
      return;
    }
    // Sinon, on signe à la volée (si on a stocké un path)
    const { data, error } = await supabase.storage.from("documents").createSignedUrl(doc.file_url, 60 * 60);
    if (error) {
      setErr(error.message);
      return;
    }
    window.open(data.signedUrl, "_blank");
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Documents</h1>
        <p className="text-slate-500 mt-1">Centralisez CV, rapports et fichiers générés.</p>
      </div>

      <div className="bg-white/80 border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="grid gap-3 md:grid-cols-4">
          <input
            placeholder="Candidate ID (uuid)"
            value={candidateId}
            onChange={(e) => setCandidateId(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none md:col-span-1"
          />

          <select
            value={fileType}
            onChange={(e) => setFileType(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none md:col-span-1"
          >
            <option value="CV">CV</option>
            <option value="Rapport">Rapport</option>
            <option value="Fichier IA">Fichier IA</option>
            <option value="Autre">Autre</option>
          </select>

          <input
            type="file"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none md:col-span-1"
          />

          <button
            onClick={upload}
            disabled={busy}
            className="gradient-bg text-white font-extrabold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow w-fit disabled:opacity-75 md:col-span-1"
          >
            {busy ? "Upload..." : "Ajouter"}
          </button>
        </div>

        {err ? <div className="mt-3 text-sm font-semibold text-red-600">❌ {err}</div> : null}
        {ok ? <div className="mt-3 text-sm font-semibold text-green-700">✅ {ok}</div> : null}
      </div>

      {loading ? (
        <div className="text-slate-600">Chargement...</div>
      ) : (
        <div className="grid gap-4">
          {items.map((d) => (
            <div key={d.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="font-extrabold text-slate-900">
                  <span className="px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-100 mr-2">
                    {d.file_type}
                  </span>
                  Document
                </div>
                <div className="text-xs text-slate-500">{new Date(d.created_at).toLocaleString()}</div>
              </div>

              <div className="mt-2 text-sm text-slate-600">
                <b>Candidate ID :</b> {d.candidate_id}
              </div>

              <div className="mt-4 flex items-center gap-3 flex-wrap">
                <button
                  onClick={() => openDoc(d)}
                  className="px-4 py-2 rounded-full border border-slate-200 bg-white hover:bg-slate-50 font-bold"
                >
                  Ouvrir
                </button>
                <div className="text-xs text-slate-500">
                  {d.file_url.startsWith("http") ? "URL signée" : "Path storage"}
                </div>
              </div>
            </div>
          ))}

          {items.length === 0 ? <div className="text-slate-500">Aucun document pour le moment.</div> : null}
        </div>
      )}
    </div>
  );
}
