"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export default function DashboardPage() {
  const [email, setEmail] = useState<string>("");
  const [name, setName] = useState<string>("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      const u = data.user;
      if (!u) return;
      setEmail(u.email ?? "");
      const fullName =
        (u.user_metadata as any)?.full_name ||
        (u.user_metadata as any)?.name ||
        (u.user_metadata as any)?.fullName ||
        "";
      setName(fullName);
    })();
  }, []);

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    const tg = h < 12 ? "Bonjour" : h < 18 ? "Bon après-midi" : "Bonsoir";
    const first = (name || "").trim().split(/\s+/)[0];
    if (first) return `${tg}, ${first}`;
    const emailName = email.split("@")[0];
    if (emailName) return `${tg}, ${emailName}`;
    return "Bienvenue sur TalentPilot AI";
  }, [email, name]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-24 md:pb-8">
      {/* En-tête */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900" aria-live="polite">
            {greeting}
          </h1>
          <p className="text-slate-500 mt-1">Votre assistant IA pour le recrutement professionnel</p>
        </div>
      </div>

      {/* Cards (visuel) */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { title: "Candidats", value: "—" },
          { title: "Offres d'emploi", value: "—" },
          { title: "Entrevues", value: "—" },
          { title: "Générations IA", value: "—" },
        ].map((c) => (
          <div key={c.title} className="bg-white/80 border border-slate-200 rounded-2xl p-5 shadow-sm">
            <div className="text-sm text-slate-500">{c.title}</div>
            <div className="text-2xl font-semibold text-slate-900 mt-2">{c.value}</div>
            <div className="text-xs text-slate-500 mt-2">Connecté : {email || "…"}</div>
          </div>
        ))}
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="font-semibold text-slate-900">Aperçu</div>
        <div className="text-slate-600 mt-1 text-sm">
          Cette page reprend la structure visuelle du dashboard Base44. Vous pouvez ensuite brancher les données Supabase
          (candidats, offres, entrevues, etc.) sans modifier le design.
        </div>
      </div>
    </div>
  );
}
