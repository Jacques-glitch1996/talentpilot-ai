"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

export default function ProfilePage() {
  const router = useRouter();
  const [email, setEmail] = useState<string>("");
  const [name, setName] = useState<string>("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      const u = data.user;
      if (!u) return;
      setEmail(u.email ?? "");
      const fullName =
        (u.user_metadata as any)?.full_name ||
        (u.user_metadata as any)?.name ||
        (u.user_metadata as any)?.fullName ||
        "";
      setName(fullName);
    })();
  }, []);

  const logout = async () => {
    await supabase.auth.signOut();
    router.push("/login");
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Profil</h1>
          <p className="text-slate-500 mt-1">Compte et session.</p>
        </div>
        <button
          onClick={logout}
          className="gradient-bg text-white font-extrabold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow w-fit"
        >
          Déconnexion
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="grid gap-2">
          <div className="text-sm text-slate-500">Nom</div>
          <div className="font-semibold text-slate-900">{name || "—"}</div>

          <div className="text-sm text-slate-500 mt-3">Courriel</div>
          <div className="font-semibold text-slate-900">{email || "—"}</div>
        </div>
      </div>
    </div>
  );
}
