"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type AiLog = {
  id: string;
  type: string;
  input: string;
  output: string;
  created_at: string;
};

export default function HistoryPage() {
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const [logs, setLogs] = useState<AiLog[]>([]);

  // Filtres
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [query, setQuery] = useState<string>("");
  const [limit, setLimit] = useState<number>(50);

  // UI
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      await refresh();
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refresh = async () => {
    setErr("");

    const { data, error } = await supabase
      .from("ai_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(limit);

    if (error) {
      setErr(error.message);
      setLogs([]);
      return;
    }

    setLogs((data ?? []) as AiLog[]);
  };

  const types = useMemo(() => {
    const set = new Set<string>();
    logs.forEach((l) => set.add(l.type || "unknown"));
    return ["all", ...Array.from(set).sort((a, b) => a.localeCompare(b))];
  }, [logs]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();

    return logs.filter((l) => {
      const okType = typeFilter === "all" ? true : (l.type || "") === typeFilter;
      if (!okType) return false;

      if (!q) return true;

      const hay =
        `${l.type}\n${l.input}\n${l.output}`.toLowerCase();

      return hay.includes(q);
    });
  }, [logs, typeFilter, query]);

  const humanDate = (iso: string) => {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleString();
  };

  const short = (txt: string, n = 220) => {
    const t = (txt ?? "").trim();
    if (t.length <= n) return t;
    return t.slice(0, n) + "…";
  };

  const copy = async (id: string, content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1200);
    } catch {
      // fallback: rien
    }
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Historique</h1>
          <p className="text-slate-500 mt-1">Journal des générations AI (audit, traçabilité, qualité).</p>
        </div>
        <button
          onClick={refresh}
          className="gradient-bg text-white font-extrabold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow w-fit"
        >
          Actualiser
        </button>
      </div>

      {/* Filtres */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none"
        >
          {types.map((t) => (
            <option key={t} value={t}>
              {t === "all" ? "Tous les types" : t}
            </option>
          ))}
        </select>

        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Recherche (type, input, output)…"
          className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none md:col-span-2"
        />

        <div className="flex gap-3">
          <select
            value={String(limit)}
            onChange={(e) => setLimit(Number(e.target.value))}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none flex-1"
          >
            <option value="25">25 derniers</option>
            <option value="50">50 derniers</option>
            <option value="100">100 derniers</option>
            <option value="200">200 derniers</option>
          </select>
          <button
            onClick={refresh}
            className="h-11 px-4 rounded-full border border-slate-200 bg-white hover:bg-slate-50 font-extrabold"
            title="Appliquer limite / recharger"
          >
            Appliquer
          </button>
        </div>
      </div>

      {err ? <div className="text-sm font-semibold text-red-600">❌ {err}</div> : null}

      {/* Liste */}
      {loading ? (
        <div className="text-slate-600">Chargement...</div>
      ) : (
        <>
          <div className="text-sm text-slate-500">{filtered.length} résultat(s) affiché(s)</div>
          <div className="grid gap-4">
            {filtered.map((l) => {
              const expanded = expandedId === l.id;

              return (
                <div key={l.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="flex gap-3 items-center flex-wrap">
                      <span className="px-3 py-1 rounded-full bg-violet-50 text-violet-700 text-xs font-extrabold border border-violet-100">
                        {l.type || "unknown"}
                      </span>
                      <span className="text-xs text-slate-500">{humanDate(l.created_at)}</span>
                    </div>

                    <div className="flex gap-2 flex-wrap">
                      <button
                        onClick={() => copy(l.id, l.output || "")}
                        className="px-4 py-2 rounded-full border border-slate-200 bg-white hover:bg-slate-50 font-extrabold text-sm"
                        title="Copier le résultat"
                      >
                        {copiedId === l.id ? "✅ Copié" : "Copier"}
                      </button>
                      <button
                        onClick={() => setExpandedId(expanded ? null : l.id)}
                        className="px-4 py-2 rounded-full border border-slate-200 bg-white hover:bg-slate-50 font-extrabold text-sm"
                      >
                        {expanded ? "Réduire" : "Détails"}
                      </button>
                    </div>
                  </div>

                  <div className="mt-4 text-sm text-slate-700">
                    <b>Input :</b> {expanded ? l.input || "—" : short(l.input || "—")}
                  </div>
                  <div className="mt-3 text-sm text-slate-700">
                    <b>Output :</b> {expanded ? l.output || "—" : short(l.output || "—")}
                  </div>
                </div>
              );
            })}

            {filtered.length === 0 ? <div className="text-slate-500">Aucun élément ne correspond à vos filtres.</div> : null}
          </div>
        </>
      )}
    </div>
  );
}
