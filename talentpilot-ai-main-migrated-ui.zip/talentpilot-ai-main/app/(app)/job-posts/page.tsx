"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type JobPost = {
  id: string;
  title: string;
  description: string;
  status: string;
};

export default function JobPostsPage() {
  const [jobs, setJobs] = useState<JobPost[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: list } = await supabase
        .from("job_posts")
        .select("*")
        .order("created_at", { ascending: false });

      setJobs(list || []);
      setLoading(false);
    })();
  }, []);

  const addJob = async () => {
    if (!title || !description) return;

    const { data, error } = await supabase
      .from("job_posts")
      .insert({
        title,
        description,
        status: "open",
      })
      .select()
      .single();

    if (!error && data) {
      setJobs([data, ...jobs]);
      setTitle("");
      setDescription("");
    }
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Offres d’emploi</h1>
        <p className="text-slate-500 mt-1">Créez et gérez vos opportunités.</p>
      </div>

      <div className="bg-white/80 border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="grid gap-3">
          <input
            placeholder="Titre du poste"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none focus:ring-2 focus:ring-blue-200"
          />
          <textarea
            placeholder="Description du poste"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="px-4 py-3 rounded-xl border border-slate-200 bg-white/90 outline-none focus:ring-2 focus:ring-blue-200"
          />

          <button
            onClick={addJob}
            className="gradient-bg text-white font-semibold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow w-fit"
          >
            Créer l’offre
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-slate-600">Chargement...</div>
      ) : (
        <div className="grid gap-4">
          {jobs.map((job) => (
            <div key={job.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <div className="font-semibold text-slate-900">{job.title}</div>
                <span className="px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold border border-blue-100">
                  {job.status}
                </span>
              </div>
              <div className="text-sm text-slate-600 mt-2 whitespace-pre-wrap">{job.description}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
