"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type KPI = {
  candidates: number;
  job_posts: number;
  messages: number;
  interviews: number;
  documents: number;
  ai_logs: number;
};

export default function PerformancePage() {
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [kpi, setKpi] = useState<KPI>({
    candidates: 0,
    job_posts: 0,
    messages: 0,
    interviews: 0,
    documents: 0,
    ai_logs: 0,
  });

  useEffect(() => {
    (async () => {
      await loadKpis();
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadKpis = async () => {
    setErr("");

    const tables = ["candidates", "job_posts", "messages", "interviews", "documents", "ai_logs"] as const;

    const results = await Promise.all(
      tables.map(async (t) => {
        const { count, error } = await supabase
          .from(t)
          .select("*", { count: "exact", head: true });

        return { table: t, count: count ?? 0, error };
      })
    );

    const firstErr = results.find((r) => r.error)?.error;
    if (firstErr) {
      setErr(firstErr.message);
      return;
    }

    const next: KPI = {
      candidates: results.find((r) => r.table === "candidates")?.count ?? 0,
      job_posts: results.find((r) => r.table === "job_posts")?.count ?? 0,
      messages: results.find((r) => r.table === "messages")?.count ?? 0,
      interviews: results.find((r) => r.table === "interviews")?.count ?? 0,
      documents: results.find((r) => r.table === "documents")?.count ?? 0,
      ai_logs: results.find((r) => r.table === "ai_logs")?.count ?? 0,
    };

    setKpi(next);
  };

  const cards = useMemo(
    () => [
      { label: "Candidats", value: kpi.candidates, hint: "Base candidats" },
      { label: "Offres d’emploi", value: kpi.job_posts, hint: "Postes actifs / créés" },
      { label: "Messages", value: kpi.messages, hint: "Communication" },
      { label: "Entrevues", value: kpi.interviews, hint: "Planifiées / créées" },
      { label: "Documents", value: kpi.documents, hint: "CV, rapports, fichiers" },
      { label: "Générations AI", value: kpi.ai_logs, hint: "Historique IA" },
    ],
    [kpi]
  );

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Performances</h1>
          <p className="text-slate-500 mt-1">Indicateurs clés pour piloter votre recrutement.</p>
        </div>
        <button
          onClick={loadKpis}
          className="gradient-bg text-white font-extrabold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow w-fit"
        >
          Actualiser
        </button>
      </div>

      {err ? <div className="text-sm font-semibold text-red-600">❌ {err}</div> : null}

      {loading ? (
        <div className="text-slate-600">Chargement...</div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {cards.map((c) => (
              <div key={c.label} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
                <div className="flex items-center justify-between gap-3">
                  <div className="font-extrabold text-slate-900">{c.label}</div>
                  <div className="gradient-text text-3xl font-extrabold leading-none">{c.value}</div>
                </div>
                <div className="mt-2 text-sm text-slate-500">{c.hint}</div>
              </div>
            ))}
          </div>

          <div className="bg-white/80 border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="font-extrabold text-slate-900">Résumé</div>
            <div className="text-sm text-slate-700 mt-2">
              Vous avez <b>{kpi.candidates}</b> candidats, <b>{kpi.job_posts}</b> offres, <b>{kpi.messages}</b> messages,
              <b> {kpi.interviews}</b> entrevues, <b>{kpi.documents}</b> documents et <b>{kpi.ai_logs}</b> générations AI.
            </div>
          </div>
        </>
      )}
    </div>
  );
}
