"use client";

import { useEffect, useRef, useState } from "react";
import { MessageCircle, X, Send, Minimize2 } from "lucide-react";

type Msg = { role: "user" | "assistant"; content: string };

export default function SupportChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Bonjour! 👋 Je suis votre assistant TalentPilot AI. Comment puis-je vous aider aujourd'hui?",
    },
  ]);
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isOpen]);

  const handleSend = () => {
    const text = input.trim();
    if (!text) return;

    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setInput("");

    // Placeholder (UI seulement) – à brancher sur votre backend IA quand prêt.
    window.setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "Je suis prêt à être connecté à votre backend IA. Pour l'instant, ceci est une réponse de démonstration (UI seulement).",
        },
      ]);
    }, 500);
  };

  return (
    <>
      {!isOpen && (
        <div className="fixed bottom-20 right-6 md:bottom-8 md:right-8 z-50">
          <button
            onClick={() => setIsOpen(true)}
            className="h-14 w-14 rounded-full shadow-lg gradient-bg hover:scale-110 transition-transform text-white flex items-center justify-center"
            aria-label="Ouvrir le chatbot"
          >
            <MessageCircle className="h-6 w-6" />
          </button>
        </div>
      )}

      {isOpen && (
        <div
          className="fixed bottom-20 right-6 md:bottom-8 md:right-8 w-[calc(100vw-3rem)] max-w-[400px] md:w-[400px] h-[500px] md:h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col z-50 border border-slate-200"
          style={{ animation: "tpChatIn 160ms ease-out" }}
        >
          {/* Header */}
          <div className="gradient-bg p-4 rounded-t-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 bg-white/20 rounded-lg flex items-center justify-center">
                <MessageCircle className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Assistant TalentPilot</h3>
                <p className="text-xs text-white/80">En ligne</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setIsOpen(false)}
                className="h-8 w-8 text-white hover:bg-white/20 rounded-md flex items-center justify-center"
                aria-label="Réduire"
              >
                <Minimize2 className="h-4 w-4" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="h-8 w-8 text-white hover:bg-white/20 rounded-md flex items-center justify-center"
                aria-label="Fermer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
            {messages.map((m, i) => (
              <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
                <div
                  className={
                    "max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed " +
                    (m.role === "user"
                      ? "bg-blue-600 text-white"
                      : "bg-white border border-slate-200 text-slate-800")
                  }
                >
                  {m.content}
                </div>
              </div>
            ))}
            <div ref={endRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-slate-200 bg-white rounded-b-2xl">
            <div className="flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Posez votre question..."
                className="flex-1 h-10 px-3 rounded-lg border border-slate-200 bg-white outline-none focus:ring-2 focus:ring-blue-200"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim()}
                className="h-10 w-10 rounded-lg gradient-bg text-white flex items-center justify-center disabled:opacity-50"
                aria-label="Envoyer"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>

          <style jsx>{`
            @keyframes tpChatIn {
              from {
                opacity: 0;
                transform: translateY(12px) scale(0.98);
              }
              to {
                opacity: 1;
                transform: translateY(0) scale(1);
              }
            }
          `}</style>
        </div>
      )}
    </>
  );
}
