"use client";

import { Search } from "lucide-react";
import { useEffect, useRef, useState } from "react";

export default function HoverSearch() {
  const [open, setOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showResults, setShowResults] = useState(false);

  const inputRef = useRef<HTMLInputElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const compute = () => setIsMobile(window.innerWidth < 768);
    compute();
    window.addEventListener("resize", compute);
    return () => window.removeEventListener("resize", compute);
  }, []);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (!containerRef.current) return;
      if (!containerRef.current.contains(e.target as Node)) {
        setShowResults(false);
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  const handleInputChange = (v: string) => {
    setSearchQuery(v);
    setShowResults(v.trim().length >= 2);
  };

  // Mobile: icône qui s'étend au clic
  if (isMobile) {
    return (
      <div className="relative" ref={containerRef}>
        <div
          className="relative"
          style={{ width: open ? 150 : 32, transition: "width 220ms ease" }}
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              setOpen((v) => !v);
              setTimeout(() => inputRef.current?.focus(), 60);
            }}
            className="absolute left-0 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center hover:bg-slate-100 rounded-full transition-colors z-20"
            aria-label="Rechercher"
          >
            <Search className="w-4 h-4 text-slate-600" />
          </button>

          {open && (
            <input
              ref={inputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder="Rechercher..."
              className="pl-9 pr-3 h-8 w-full rounded-full bg-slate-50 border border-slate-200 text-xs text-gray-700 placeholder-gray-500 outline-none"
              autoFocus
            />
          )}
        </div>

        {showResults && (
          <SearchResultsDropdown onClose={() => setShowResults(false)} />
        )}
      </div>
    );
  }

  // Desktop: animation au hover
  return (
    <div className="relative" ref={containerRef}>
      <div
        onMouseEnter={() => {
          setOpen(true);
          setTimeout(() => inputRef.current?.focus(), 120);
        }}
        onMouseLeave={() => {
          if (!showResults) setOpen(false);
        }}
        className="flex items-center h-11 rounded-full backdrop-blur-xl bg-white/40 border border-white/30 shadow-md overflow-hidden cursor-text"
        style={{ width: open ? 280 : 44, transition: "width 250ms ease" }}
        onClick={() => {
          setOpen(true);
          setTimeout(() => inputRef.current?.focus(), 60);
        }}
      >
        <div className="flex items-center justify-center w-11 h-11 text-gray-600 flex-shrink-0">
          <Search size={18} />
        </div>

        <input
          ref={inputRef}
          type="text"
          value={searchQuery}
          onChange={(e) => handleInputChange(e.target.value)}
          placeholder="Rechercher candidats, offres..."
          className="flex-1 bg-transparent text-sm text-gray-700 placeholder-gray-500 outline-none pr-4"
          style={{ opacity: open ? 1 : 0, transition: "opacity 150ms ease" }}
        />
      </div>

      {showResults && (
        <SearchResultsDropdown
          onClose={() => {
            setShowResults(false);
            setOpen(false);
          }}
        />
      )}
    </div>
  );
}

function SearchResultsDropdown({ onClose }: { onClose: () => void }) {
  return (
    <div className="absolute top-full mt-2 w-96 max-w-[calc(100vw-2rem)] bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden z-50">
      <div className="max-h-[70vh] overflow-y-auto">
        <div className="p-6 text-center text-slate-500">
          <Search className="w-8 h-8 mx-auto mb-2 text-slate-400" />
          <p className="text-sm">Aucun résultat trouvé</p>
          <button
            className="mt-4 text-xs text-blue-600 hover:underline"
            onClick={onClose}
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
}
