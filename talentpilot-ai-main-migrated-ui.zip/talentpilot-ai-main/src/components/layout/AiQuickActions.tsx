"use client";

import Link from "next/link";
import { Sparkles } from "lucide-react";

export default function AiQuickActions() {
  return (
    <Link href="/automations" className="hidden md:fixed bottom-20 right-6 md:bottom-6 z-50">
      <button
        className="bg-gradient-to-br from-[#7C3AED] to-[#1E40AF] text-white p-4 rounded-full shadow-2xl hover:shadow-[#7C3AED]/50 transition-transform"
        style={{ transform: "translateZ(0)" }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.08)";
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)";
        }}
        aria-label="Actions IA"
      >
        <Sparkles size={24} />
      </button>
    </Link>
  );
}
