"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Bell, Calendar, Settings } from "lucide-react";
import HoverSearch from "./HoverSearch";
import { supabase } from "@/lib/supabaseClient";

type UserInfo = {
  full_name?: string;
  email?: string;
  profile_picture?: string;
};

function initials(nameOrEmail?: string) {
  const v = (nameOrEmail || "U").trim();
  if (!v) return "U";
  const parts = v.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return v.slice(0, 2).toUpperCase();
}

export default function AppHeader() {
  const pathname = usePathname();

  const [user, setUser] = useState<UserInfo | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);

  const notifClose = useRef<number | null>(null);
  const calClose = useRef<number | null>(null);

  // Base44: actuellement tableau vide
  const notifications: Array<{ id: string; title: string; message: string; read?: boolean }> = [];
  const upcomingEvents: Array<{ id: string; title: string; location?: string }> = [];
  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      const u = data.user;
      if (!u) {
        setUser(null);
        return;
      }

      const full_name =
        (u.user_metadata as any)?.full_name ||
        (u.user_metadata as any)?.name ||
        (u.user_metadata as any)?.fullName ||
        undefined;

      const profile_picture =
        (u.user_metadata as any)?.profile_picture ||
        (u.user_metadata as any)?.avatar_url ||
        (u.user_metadata as any)?.picture ||
        undefined;

      setUser({
        full_name,
        email: u.email ?? undefined,
        profile_picture,
      });
    })();
  }, []);

  // Fermer les panneaux au changement de route
  useEffect(() => {
    setShowNotifications(false);
    setShowCalendar(false);
  }, [pathname]);

  const scheduleClose = (kind: "notif" | "cal") => {
    const ref = kind === "notif" ? notifClose : calClose;
    const setter = kind === "notif" ? setShowNotifications : setShowCalendar;

    if (ref.current) window.clearTimeout(ref.current);
    ref.current = window.setTimeout(() => setter(false), 300);
  };

  const cancelClose = (kind: "notif" | "cal") => {
    const ref = kind === "notif" ? notifClose : calClose;
    if (ref.current) {
      window.clearTimeout(ref.current);
      ref.current = null;
    }
  };

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-white/30 border-b border-white/20 shadow-lg">
      <div className="w-full px-6 py-4">
        <div className="flex items-center justify-between gap-2 md:gap-4">
          {/* Logo à gauche */}
          <Link
            href="/dashboard"
            className="flex items-center gap-3 hover:opacity-80 transition-opacity flex-shrink-0"
          >
            <img
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69646db0883c6e471326ee4a/5f332e2e5_TalentPilotAI-Logo2026.png"
              alt="TalentPilot AI Logo"
              className="h-10 w-10 md:h-8 md:w-8 rounded-lg"
            />
            <div className="text-xl font-semibold tracking-wide gradient-text hidden sm:block">
              TalentPilot AI
            </div>
          </Link>

          {/* Barre de recherche (Desktop) */}
          <div className="hidden md:block md:ml-auto">
            <HoverSearch />
          </div>

          {/* Recherche au centre (Mobile) */}
          <div className="flex md:hidden mx-auto">
            <HoverSearch />
          </div>

          {/* Settings à droite (Mobile) */}
          <div className="flex md:hidden">
            <Link href="/settings" className="inline-flex">
              <button
                className="hover:bg-slate-100 h-8 w-8 inline-flex items-center justify-center rounded-md transition-colors"
                aria-label="Paramètres"
              >
                <Settings className="w-4 h-4 text-slate-600" />
              </button>
            </Link>
          </div>

          {/* Navigation icônes à droite (Desktop uniquement) */}
          <div className="hidden md:flex items-center gap-2">
            {/* Settings */}
            <Link href="/settings" className="inline-flex">
              <button
                className="hover:bg-slate-100 h-10 w-10 inline-flex items-center justify-center rounded-md transition-colors"
                aria-label="Paramètres"
              >
                <Settings className="w-5 h-5 text-slate-600" />
              </button>
            </Link>

            {/* Alertes */}
            <div
              className="relative"
              onMouseEnter={() => {
                cancelClose("notif");
                setShowNotifications(true);
              }}
              onMouseLeave={() => scheduleClose("notif")}
            >
              <Link href="/notifications" className="inline-flex">
                <button
                  className="relative hover:bg-slate-100 h-10 w-10 inline-flex items-center justify-center rounded-md transition-colors"
                  aria-label="Notifications"
                >
                  <Bell className="w-5 h-5 text-slate-600" />
                  {unreadCount > 0 && (
                    <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full" />
                  )}
                </button>
              </Link>

              {showNotifications && (
                <div className="absolute top-full right-0 mt-2 w-80 z-[9999]">
                  <div className="bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
                    <div className="p-4 border-b border-slate-200 bg-gradient-to-r from-blue-50 to-purple-50">
                      <h3 className="font-semibold text-slate-900">Notifications</h3>
                      {unreadCount > 0 && (
                        <p className="text-xs text-slate-600 mt-1">
                          {unreadCount} non lue{unreadCount > 1 ? "s" : ""}
                        </p>
                      )}
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <div className="p-8 text-center text-slate-500">
                          <Bell className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                          <p className="text-sm">Aucune notification</p>
                        </div>
                      ) : (
                        notifications.map((n) => (
                          <div key={n.id} className="p-4 border-b border-slate-100 hover:bg-slate-50 transition-colors cursor-pointer">
                            <p className="font-medium text-slate-900 text-sm">{n.title}</p>
                            <p className="text-xs text-slate-500 mt-1 line-clamp-2">{n.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                    <Link href="/notifications" className="block">
                      <div className="p-3 text-center border-t border-slate-200 hover:bg-slate-50 transition-colors">
                        <span className="text-sm font-medium text-blue-600">Voir toutes les notifications</span>
                      </div>
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {/* Calendrier */}
            <div
              className="relative"
              onMouseEnter={() => {
                cancelClose("cal");
                setShowCalendar(true);
              }}
              onMouseLeave={() => scheduleClose("cal")}
            >
              <Link href="/calendar" className="inline-flex">
                <button
                  className="relative hover:bg-slate-100 h-10 w-10 inline-flex items-center justify-center rounded-md transition-colors"
                  aria-label="Calendrier"
                >
                  <Calendar className="w-5 h-5 text-slate-600" />
                  {upcomingEvents.length > 0 && (
                    <span className="absolute top-2 right-2 w-2 h-2 bg-blue-500 rounded-full" />
                  )}
                </button>
              </Link>

              {showCalendar && (
                <div className="absolute top-full right-0 mt-2 w-80 z-[9999]">
                  <div className="bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
                    <div className="p-4 border-b border-slate-200 bg-gradient-to-r from-indigo-50 to-blue-50">
                      <h3 className="font-semibold text-slate-900">Événements à venir</h3>
                      <p className="text-xs text-slate-600 mt-1">
                        {upcomingEvents.length} événement{upcomingEvents.length > 1 ? "s" : ""}
                      </p>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {upcomingEvents.length === 0 ? (
                        <div className="p-8 text-center text-slate-500">
                          <Calendar className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                          <p className="text-sm">Aucun événement</p>
                        </div>
                      ) : (
                        upcomingEvents.map((e) => (
                          <div key={e.id} className="p-4 border-b border-slate-100 hover:bg-slate-50 transition-colors cursor-pointer">
                            <p className="font-medium text-slate-900 text-sm">{e.title}</p>
                            <p className="text-xs text-slate-500 mt-1">{e.location}</p>
                          </div>
                        ))
                      )}
                    </div>
                    <Link href="/calendar" className="block">
                      <div className="p-3 text-center border-t border-slate-200 hover:bg-slate-50 transition-colors">
                        <span className="text-sm font-medium text-indigo-600">Voir le calendrier complet</span>
                      </div>
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {/* Profil */}
            <Link href="/profile" className="inline-flex" aria-label="Profil">
              <button className="hover:bg-slate-100 rounded-full p-1 transition-colors">
                <div className="h-8 w-8 rounded-full overflow-hidden bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                  {user?.profile_picture ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={user.profile_picture}
                      alt={user.full_name || user.email || "Utilisateur"}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <span className="text-white text-sm font-semibold">
                      {initials(user?.full_name || user?.email)}
                    </span>
                  )}
                </div>
              </button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
