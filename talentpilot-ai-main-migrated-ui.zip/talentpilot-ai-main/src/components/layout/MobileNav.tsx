"use client";

import Link from "next/link";
import { useState } from "react";
import {
  Home,
  Briefcase,
  Sparkles,
  User,
  X,
  ChevronDown,
  MessageSquare,
  FileText,
  BarChart3,
  Bell,
  Calendar,
  CheckSquare,
  GitBranch,
} from "lucide-react";

type Section = {
  label: string;
  icon: any;
  submenu: Array<{ label: string; href: string; pageKey: string }>;
};

const sections: Section[] = [
  {
    label: "Recrutement",
    icon: Briefcase,
    submenu: [
      { label: "Candidats", href: "/candidates", pageKey: "Candidates" },
      { label: "Offres d'emploi", href: "/job-posts", pageKey: "JobPosts" },
      { label: "Entrevues", href: "/interviews", pageKey: "Interviews" },
      { label: "Questions d'entrevue", href: "/interview-questions", pageKey: "InterviewQuestions" },
    ],
  },
  {
    label: "Communication",
    icon: MessageSquare,
    submenu: [
      { label: "Messages", href: "/messages", pageKey: "Messages" },
      { label: "Suivis candidats", href: "/candidate-follow-up", pageKey: "CandidateFollowUp" },
    ],
  },
  {
    label: "Assistant IA",
    icon: Sparkles,
    submenu: [
      { label: "Génération intelligente", href: "/automations", pageKey: "Automations" },
      { label: "Assistant de matching", href: "/ai-matching", pageKey: "AIMatching" },
      { label: "Centre d'insights", href: "/ai-insights", pageKey: "AIInsights" },
    ],
  },
  {
    label: "Tâches",
    icon: CheckSquare,
    submenu: [
      { label: "Dashboard activités", href: "/activity-dashboard", pageKey: "ActivityDashboard" },
      { label: "Rappels & Suivis", href: "/reminders", pageKey: "Reminders" },
      { label: "Notes rapides", href: "/quick-notes", pageKey: "QuickNotes" },
    ],
  },
  {
    label: "Documents",
    icon: FileText,
    submenu: [
      { label: "Documents RH", href: "/hr-documents", pageKey: "HRDocuments" },
      { label: "CV", href: "/cv-documents", pageKey: "CVDocuments" },
      { label: "Rapports", href: "/reports", pageKey: "Reports" },
      { label: "Fichiers générés par l'IA", href: "/generated-files", pageKey: "GeneratedFiles" },
    ],
  },
  {
    label: "Analyse",
    icon: BarChart3,
    submenu: [{ label: "Performances", href: "/performance", pageKey: "Performances" }],
  },
  {
    label: "Processus",
    icon: GitBranch,
    submenu: [{ label: "Workflows & Checklists", href: "/workflows", pageKey: "Workflows" }],
  },
];

const bottomNavItems = [
  { label: "Accueil", icon: Home, href: "/dashboard", pageKey: "Dashboard" },
  { label: "Notifications", icon: Bell, href: "/notifications", pageKey: "Notifications" },
  { label: "Calendrier", icon: Calendar, href: "/calendar", pageKey: "Calendar" },
  { label: "Profil", icon: User, href: "/profile", pageKey: "Profile" },
];

function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function SectionMenuItem({
  section,
  currentPageName,
  onNavigate,
}: {
  section: Section;
  currentPageName: string;
  onNavigate: () => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const hasSubmenu = section.submenu?.length > 0;
  const isAnyActive = section.submenu?.some((item) => item.pageKey === currentPageName);
  const Icon = section.icon;

  return (
    <div>
      <button
        onClick={() => setIsOpen((v) => !v)}
        className={cn(
          "flex items-center gap-3 w-full px-4 py-3 rounded-lg transition-colors text-sm font-medium",
          isAnyActive ? "bg-[#7C3AED]/10 text-[#7C3AED]" : "text-gray-600 hover:bg-slate-100"
        )}
      >
        <Icon size={18} />
        <span className="flex-1 text-left">{section.label}</span>
        {hasSubmenu && (
          <span
            className="transition-transform"
            style={{ transform: isOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 200ms ease" }}
          >
            <ChevronDown size={14} />
          </span>
        )}
      </button>

      {isOpen && hasSubmenu && (
        <div
          className="overflow-hidden"
          style={{
            animation: "tpExpand 150ms ease",
          }}
        >
          <div className="pl-8 space-y-1">
            {section.submenu.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                onClick={onNavigate}
                className={cn(
                  "block px-4 py-2 rounded-lg text-sm transition-colors",
                  currentPageName === item.pageKey
                    ? "bg-[#7C3AED]/10 text-[#7C3AED] font-medium"
                    : "text-gray-600 hover:bg-slate-100"
                )}
              >
                {item.label}
              </Link>
            ))}
          </div>

          <style jsx>{`
            @keyframes tpExpand {
              from {
                opacity: 0;
                transform: translateY(-2px);
              }
              to {
                opacity: 1;
                transform: translateY(0);
              }
            }
          `}</style>
        </div>
      )}
    </div>
  );
}

export default function MobileNav({ currentPageName }: { currentPageName: string }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Hamburger Menu Button */}
      <button
        onClick={() => setIsOpen((v) => !v)}
        className="md:hidden fixed top-20 right-4 z-50 p-3 hover:bg-slate-100 rounded-lg bg-white border border-slate-200 shadow-lg"
        aria-label="Menu"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>

      {isOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-black/50" onClick={() => setIsOpen(false)} />
      )}

      {/* Side Drawer */}
      <nav
        className="md:hidden fixed left-0 top-0 h-screen w-64 bg-white border-r border-slate-200 z-50 flex flex-col"
        style={{
          transform: isOpen ? "translateX(0)" : "translateX(-100%)",
          transition: "transform 320ms cubic-bezier(0.2, 0.8, 0.2, 1)",
        }}
      >
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div className="text-lg font-semibold tracking-wide gradient-text whitespace-nowrap">TalentPilot AI</div>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-slate-100 rounded"
            aria-label="Fermer"
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-4 space-y-2 flex-1 overflow-y-auto">
          {sections.map((section) => (
            <SectionMenuItem
              key={section.label}
              section={section}
              currentPageName={currentPageName}
              onNavigate={() => setIsOpen(false)}
            />
          ))}
        </div>
      </nav>

      {/* Bottom Navigation Bar - Mobile Only */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-40 pb-safe rounded-t-3xl shadow-lg">
        <div className="flex items-center justify-around px-2 py-3">
          {bottomNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPageName === item.pageKey;

            return (
              <Link key={item.pageKey} href={item.href} className="flex-1 flex flex-col items-center gap-1 relative">
                <div
                  className={cn(
                    "flex flex-col items-center gap-1 px-4 py-2 rounded-2xl transition-all",
                    isActive && "bg-gradient-to-r from-blue-50 to-violet-50"
                  )}
                >
                  <div
                    className={cn(
                      "p-2 rounded-xl transition-all",
                      isActive ? "bg-gradient-to-r from-blue-600 to-violet-600" : "bg-transparent"
                    )}
                  >
                    <Icon className={cn("w-5 h-5 transition-colors", isActive ? "text-white" : "text-slate-600")} />
                  </div>
                  <span
                    className={cn(
                      "text-xs font-medium transition-colors",
                      isActive
                        ? "bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent"
                        : "text-slate-600"
                    )}
                  >
                    {item.label}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
}
