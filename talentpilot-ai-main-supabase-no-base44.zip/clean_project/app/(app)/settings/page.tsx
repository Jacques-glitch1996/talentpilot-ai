export default function PlaceholderPage() {
  return (
    <div className="space-y-4 pb-24 md:pb-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">En cours</h1>
        <p className="text-slate-500 mt-1">
          Cette page est en place pour reproduire l’interface . Vous pourrez ensuite brancher la logique Supabase.
        </p>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="font-semibold text-slate-900">Contenu</div>
        <div className="text-sm text-slate-600 mt-2">
          Ajoutez ici vos composants et vos données.
        </div>
      </div>
    </div>
  );
}
