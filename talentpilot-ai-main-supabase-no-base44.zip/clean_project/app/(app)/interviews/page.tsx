"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type Interview = {
  id: string;
  candidate_id: string;
  job_post_id: string;
  interview_date: string | null;
  notes: string | null;
  created_at: string;
};

export default function InterviewsPage() {
  const [items, setItems] = useState<Interview[]>([]);
  const [candidateId, setCandidateId] = useState("");
  const [jobPostId, setJobPostId] = useState("");
  const [interviewDate, setInterviewDate] = useState(""); // datetime-local string
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      await refresh();
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refresh = async () => {
    setErr("");
    const { data, error } = await supabase
      .from("interviews")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      setErr(error.message);
      setItems([]);
      return;
    }
    setItems((data ?? []) as Interview[]);
  };

  const addInterview = async () => {
    setErr("");
    if (!candidateId.trim() || !jobPostId.trim()) {
      setErr("Candidate ID et Job Post ID sont requis.");
      return;
    }

    const iso = interviewDate ? new Date(interviewDate).toISOString() : null;

    const { data, error } = await supabase
      .from("interviews")
      .insert({
        candidate_id: candidateId.trim(),
        job_post_id: jobPostId.trim(),
        interview_date: iso,
        notes: notes.trim() || null,
      })
      .select()
      .single();

    if (error) {
      setErr(error.message);
      return;
    }

    setItems([data as Interview, ...items]);
    setCandidateId("");
    setJobPostId("");
    setInterviewDate("");
    setNotes("");
  };

  const humanDate = (iso?: string | null) => {
    if (!iso) return "—";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "—";
    return d.toLocaleString();
  };

  const grouped = useMemo(() => {
    const map = new Map<string, Interview[]>();
    for (const it of items) {
      const key = (it.interview_date ?? it.created_at).slice(0, 10);
      map.set(key, [...(map.get(key) ?? []), it]);
    }
    return Array.from(map.entries()).sort(([a], [b]) => (a < b ? 1 : -1));
  }, [items]);

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Entrevues</h1>
        <p className="text-slate-500 mt-1">Planification et suivi des entrevues.</p>
      </div>

      <div className="bg-white/80 border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="grid gap-3 md:grid-cols-2">
          <input
            placeholder="Candidate ID (uuid)"
            value={candidateId}
            onChange={(e) => setCandidateId(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none"
          />
          <input
            placeholder="Job Post ID (uuid)"
            value={jobPostId}
            onChange={(e) => setJobPostId(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none"
          />
          <input
            type="datetime-local"
            value={interviewDate}
            onChange={(e) => setInterviewDate(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none"
          />
          <button
            onClick={addInterview}
            className="gradient-bg text-white font-extrabold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow w-fit"
          >
            Ajouter une entrevue
          </button>
          <textarea
            placeholder="Notes (optionnel)"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="md:col-span-2 px-4 py-3 rounded-xl border border-slate-200 bg-white/90 outline-none resize-none"
          />
        </div>

        {err ? <div className="mt-3 text-sm font-semibold text-red-600">❌ {err}</div> : null}
      </div>

      {loading ? (
        <div className="text-slate-600">Chargement...</div>
      ) : (
        <div className="grid gap-4">
          {grouped.map(([day, list]) => (
            <div key={day} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="font-extrabold text-slate-900 mb-3">{day}</div>
              <div className="grid gap-3">
                {list.map((it) => (
                  <div key={it.id} className="bg-white/80 border border-slate-200 rounded-2xl p-4">
                    <div className="flex items-start justify-between gap-3 flex-wrap">
                      <div className="font-extrabold text-slate-900">Entrevue</div>
                      <div className="text-xs text-slate-500">{humanDate(it.interview_date)}</div>
                    </div>

                    <div className="mt-2 text-sm text-slate-600">
                      <div>
                        <b>Candidate ID :</b> {it.candidate_id}
                      </div>
                      <div>
                        <b>Job Post ID :</b> {it.job_post_id}
                      </div>
                    </div>

                    {it.notes ? <div className="mt-3 text-sm text-slate-800">{it.notes}</div> : null}
                  </div>
                ))}
              </div>
            </div>
          ))}

          {items.length === 0 ? <div className="text-slate-500">Aucune entrevue pour le moment.</div> : null}
        </div>
      )}
    </div>
  );
}
