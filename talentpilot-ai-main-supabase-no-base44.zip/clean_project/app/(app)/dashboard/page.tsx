"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type Counts = {
  candidates: number;
  job_posts: number;
  interviews: number;
  ai_logs: number;
};

export default function DashboardPage() {
  const [email, setEmail] = useState<string>("");
  const [name, setName] = useState<string>("");
  const [counts, setCounts] = useState<Counts>({
    candidates: 0,
    job_posts: 0,
    interviews: 0,
    ai_logs: 0,
  });

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      const u = data.user;
      if (!u) return;
      setEmail(u.email ?? "");
      const fullName =
        (u.user_metadata as any)?.full_name ||
        (u.user_metadata as any)?.name ||
        (u.user_metadata as any)?.fullName ||
        "";
      setName(fullName);
    })();
  }, []);

  useEffect(() => {
    (async () => {
      const [c, j, i, a] = await Promise.all([
        supabase.from("candidates").select("id", { count: "exact", head: true }),
        supabase.from("job_posts").select("id", { count: "exact", head: true }),
        supabase.from("interviews").select("id", { count: "exact", head: true }),
        supabase.from("ai_logs").select("id", { count: "exact", head: true }),
      ]);

      setCounts({
        candidates: c.count ?? 0,
        job_posts: j.count ?? 0,
        interviews: i.count ?? 0,
        ai_logs: a.count ?? 0,
      });
    })();
  }, []);

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    const tg = h < 12 ? "Bonjour" : h < 18 ? "Bon après-midi" : "Bonsoir";
    const first = (name || "").trim().split(/\s+/)[0];
    if (first) return `${tg}, ${first}`;
    const emailName = email.split("@")[0];
    if (emailName) return `${tg}, ${emailName}`;
    return "Bienvenue sur TalentPilot AI";
  }, [email, name]);

  const cards = [
    { title: "Candidats", value: counts.candidates },
    { title: "Offres d'emploi", value: counts.job_posts },
    { title: "Entrevues", value: counts.interviews },
    { title: "Générations IA", value: counts.ai_logs },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-24 md:pb-8">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900" aria-live="polite">
            {greeting}
          </h1>
          <p className="text-slate-500 mt-1">Votre assistant IA pour le recrutement professionnel</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {cards.map((c) => (
          <div key={c.title} className="bg-white/80 border border-slate-200 rounded-2xl p-5 shadow-sm">
            <div className="text-sm text-slate-500">{c.title}</div>
            <div className="text-2xl font-semibold text-slate-900 mt-2">{c.value}</div>
            <div className="text-xs text-slate-500 mt-2">Connecté : {email || "…"}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
          <div className="font-semibold text-slate-900">Aperçu</div>
          <div className="text-slate-600 mt-1 text-sm">
            Les indicateurs ci-dessus proviennent de Supabase (tables <span className="font-semibold">candidates</span>,{" "}
            <span className="font-semibold">job_posts</span>, <span className="font-semibold">interviews</span>,{" "}
            <span className="font-semibold">ai_logs</span>).
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
          <div className="font-semibold text-slate-900">Actions rapides</div>
          <div className="mt-4 flex flex-wrap gap-3">
            <a
              href="/candidates"
              className="px-4 py-2 rounded-full border border-slate-200 bg-white hover:bg-slate-50 font-bold"
            >
              Ajouter un candidat
            </a>
            <a
              href="/job-posts"
              className="px-4 py-2 rounded-full border border-slate-200 bg-white hover:bg-slate-50 font-bold"
            >
              Créer une offre
            </a>
            <a
              href="/ai"
              className="px-4 py-2 rounded-full border border-slate-200 bg-white hover:bg-slate-50 font-bold"
            >
              Générer avec l’IA
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
