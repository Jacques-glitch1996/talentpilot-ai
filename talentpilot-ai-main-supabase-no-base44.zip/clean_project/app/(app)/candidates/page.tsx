"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type Candidate = {
  id: string;
  first_name: string;
  last_name: string;
  email: string | null;
  phone: string | null;
};

export default function CandidatesPage() {
  const [list, setList] = useState<Candidate[]>([]);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const { data, error } = await supabase
      .from("candidates")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && data) setList(data);
  };

  const add = async () => {
    setErrorMsg("");

    // Validation locale AVANT Supabase
    if (!email.trim() && !phone.trim()) {
      setErrorMsg("Un email ou un téléphone est requis.");
      return;
    }

    const { error } = await supabase.from("candidates").insert({
      first_name: firstName.trim(),
      last_name: lastName.trim(),
      email: email.trim() || null,
      phone: phone.trim() || null,
    });

    if (error) {
      if (error.message.includes("candidates_email_format")) {
        setErrorMsg("Format email invalide.");
      } else if (error.message.includes("candidates_phone_format")) {
        setErrorMsg("Format téléphone invalide.");
      } else if (error.message.includes("candidates_email_or_phone_required")) {
        setErrorMsg("Un email ou un téléphone est requis.");
      } else {
        setErrorMsg(error.message);
      }
      return;
    }

    setFirstName("");
    setLastName("");
    setEmail("");
    setPhone("");
    load();
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Candidats</h1>
        <p className="text-slate-500 mt-1">Ajoutez, consultez et gérez votre vivier.</p>
      </div>

      <div className="bg-white/80 border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="grid gap-3 md:grid-cols-2">
          <input
            placeholder="Prénom"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none focus:ring-2 focus:ring-blue-200"
          />
          <input
            placeholder="Nom"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none focus:ring-2 focus:ring-blue-200"
          />
          <input
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none focus:ring-2 focus:ring-blue-200"
          />
          <input
            placeholder="Téléphone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none focus:ring-2 focus:ring-blue-200"
          />
        </div>

        {errorMsg && (
          <div className="mt-3 text-sm font-semibold text-red-600">❌ {errorMsg}</div>
        )}

        <div className="mt-4">
          <button
            onClick={add}
            className="gradient-bg text-white font-semibold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow"
          >
            Ajouter
          </button>
        </div>
      </div>

      <div className="grid gap-3">
        {list.map((c) => (
          <div
            key={c.id}
            className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm"
          >
            <div className="font-semibold text-slate-900">
              {c.first_name} {c.last_name}
            </div>
            <div className="text-sm text-slate-500 mt-1">{c.email || c.phone}</div>
          </div>
        ))}
      </div>
    </div>
  );
}