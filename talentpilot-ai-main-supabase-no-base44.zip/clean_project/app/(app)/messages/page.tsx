"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type Message = {
  id: string;
  content: string;
  channel: string;
  created_at: string;
};

export default function MessagesPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [content, setContent] = useState("");
  const [channel, setChannel] = useState("email");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: list } = await supabase
        .from("messages")
        .select("*")
        .order("created_at", { ascending: false });

      setMessages(list || []);
      setLoading(false);
    })();
  }, []);

  const addMessage = async () => {
    if (!content) return;

    const { data, error } = await supabase
      .from("messages")
      .insert({
        content,
        channel,
      })
      .select()
      .single();

    if (!error && data) {
      setMessages([data, ...messages]);
      setContent("");
    }
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Communication</h1>
        <p className="text-slate-500 mt-1">Centralisez vos échanges candidats.</p>
      </div>

      <div className="bg-white/80 border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="grid gap-3">
          <select
            value={channel}
            onChange={(e) => setChannel(e.target.value)}
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white/90 outline-none"
          >
            <option value="email">Email</option>
            <option value="linkedin">LinkedIn</option>
            <option value="phone">Téléphone</option>
          </select>

          <textarea
            placeholder="Contenu du message"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={4}
            className="px-4 py-3 rounded-xl border border-slate-200 bg-white/90 outline-none"
          />

          <button
            onClick={addMessage}
            className="gradient-bg text-white font-semibold px-5 py-2.5 rounded-full shadow-md hover:shadow-lg transition-shadow w-fit"
          >
            Ajouter message
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-slate-600">Chargement...</div>
      ) : (
        <div className="grid gap-4">
          {messages.map((msg) => (
            <div key={msg.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <span className="px-3 py-1 rounded-full bg-violet-50 text-violet-700 text-xs font-semibold border border-violet-100">
                  {msg.channel}
                </span>
                <div className="text-xs text-slate-500">{new Date(msg.created_at).toLocaleDateString()}</div>
              </div>
              <div className="text-sm text-slate-700 mt-3 whitespace-pre-wrap">{msg.content}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
