"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import {
  Home,
  Briefcase,
  MessageSquare,
  Sparkles,
  BarChart3,
  FileText,
  ChevronDown,
  CheckSquare,
  GitBranch,
} from "lucide-react";

type SectionItem = {
  label: string;
  icon: any;
  submenu: Array<{ label: string; href: string }>;
};

const sections: SectionItem[] = [
  {
    label: "Accueil",
    icon: Home,
    submenu: [{ label: "Tableau de bord", href: "/dashboard" }],
  },
  {
    label: "Recrutement",
    icon: Briefcase,
    submenu: [
      { label: "Candidats", href: "/candidates" },
      { label: "Import CSV", href: "/import-csv" },
      { label: "Offres d'emploi", href: "/job-posts" },
      { label: "Entrevues", href: "/interviews" },
      { label: "Planification IA", href: "/smart-scheduling" },
      { label: "Questions d'entrevue", href: "/interview-questions" },
    ],
  },
  {
    label: "Communication",
    icon: MessageSquare,
    submenu: [
      { label: "Messages", href: "/messages" },
      { label: "Suivis candidats", href: "/candidate-follow-up" },
    ],
  },
  {
    label: "IA",
    icon: Sparkles,
    submenu: [
      { label: "Génération intelligente", href: "/automations" },
      { label: "Assistant de matching", href: "/ai-matching" },
      { label: "Centre d'insights", href: "/ai-insights" },
    ],
  },
  {
    label: "Tâches",
    icon: CheckSquare,
    submenu: [
      { label: "Dashboard activités", href: "/activity-dashboard" },
      { label: "Rappels & Suivis", href: "/reminders" },
      { label: "Notes rapides", href: "/quick-notes" },
    ],
  },
  {
    label: "Documents",
    icon: FileText,
    submenu: [
      { label: "Documents RH", href: "/hr-documents" },
      { label: "CV", href: "/cv-documents" },
      { label: "Rapports", href: "/reports" },
      { label: "Fichiers générés", href: "/generated-files" },
    ],
  },
  {
    label: "Analyse",
    icon: BarChart3,
    submenu: [{ label: "Performances", href: "/performance" }],
  },
  {
    label: "Processus",
    icon: GitBranch,
    submenu: [{ label: "Workflows & Checklists", href: "/workflows" }],
  },
];

function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function SectionMenuItem({
  section,
  isActiveSection,
  onSectionClick,
}: {
  section: SectionItem;
  isActiveSection: boolean;
  onSectionClick: (label: string) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!isActiveSection) setIsOpen(false);
  }, [isActiveSection]);

  const Icon = section.icon;
  const hasSubmenu = section.submenu?.length > 0;

  return (
    <div
      className="relative group"
      onMouseEnter={() => {
        setIsOpen(true);
      }}
      onMouseLeave={() => {
        setIsOpen(false);
      }}
    >
      <button
        onClick={() => {
          setIsOpen((v) => !v);
          onSectionClick(section.label);
        }}
        className={cn(
          "flex items-center gap-2 px-4 py-4 text-sm font-medium whitespace-nowrap transition-colors rounded-lg",
          isActiveSection ? "gradient-text" : "text-gray-600 hover:bg-gray-200"
        )}
      >
        <Icon size={18} />
        <span>{section.label}</span>
        {hasSubmenu && (
          <span
            className="transition-transform"
            style={{ transform: isOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 200ms ease" }}
          >
            <ChevronDown size={14} />
          </span>
        )}
      </button>

      {isOpen && hasSubmenu && (
        <div
          className="absolute left-0 top-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-[9999] min-w-56 overflow-hidden"
          style={{
            transformOrigin: "top left",
            animation: "tpFadeScale 150ms ease-out",
          }}
          onMouseEnter={() => setIsOpen(true)}
          onMouseLeave={() => setIsOpen(false)}
        >
          <div className="py-1">
            {section.submenu.map((item) => (
              <Link key={item.label} href={item.href} className="block">
                <div className="px-4 py-2.5 text-sm text-gray-600 hover:bg-slate-50 transition-colors">
                  {item.label}
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes tpFadeScale {
          from {
            opacity: 0;
            transform: translateY(-8px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
      `}</style>
    </div>
  );
}

export default function SectionNav({ currentPageName }: { currentPageName: string }) {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  return (
    <nav className="bg-white border-b border-slate-200 overflow-visible hide-scrollbar">
      <div className="w-full px-4 sm:px-6 flex gap-1">
        {sections.map((section) => (
          <SectionMenuItem
            key={section.label}
            section={section}
            isActiveSection={activeSection === section.label}
            onSectionClick={setActiveSection}
          />
        ))}
      </div>
    </nav>
  );
}
