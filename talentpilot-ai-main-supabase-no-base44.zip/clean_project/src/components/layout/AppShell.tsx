"use client";

import { useEffect, useMemo, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

import AppHeader from "./AppHeader";
import SectionNav from "./SectionNav";
import MobileNav from "./MobileNav";
import AiQuickActions from "./AiQuickActions";
import SupportChatbot from "./SupportChatbot";

function getPageKeyFromPath(pathname: string): string {
  const map: Record<string, string> = {
    "/dashboard": "Dashboard",
    "/candidates": "Candidates",
    "/import-csv": "ImportCSV",
    "/job-posts": "JobPosts",
    "/interviews": "Interviews",
    "/smart-scheduling": "SmartScheduling",
    "/interview-questions": "InterviewQuestions",

    "/messages": "Messages",
    "/candidate-follow-up": "CandidateFollowUp",

    "/automations": "Automations",
    "/ai-matching": "AIMatching",
    "/ai-insights": "AIInsights",
    "/ai": "Automations", // bouton IA rapide

    "/activity-dashboard": "ActivityDashboard",
    "/reminders": "Reminders",
    "/quick-notes": "QuickNotes",

    "/hr-documents": "HRDocuments",
    "/cv-documents": "CVDocuments",
    "/reports": "Reports",
    "/generated-files": "GeneratedFiles",
    "/documents": "Documents",

    "/performance": "Performances",
    "/history": "History",

    "/workflows": "Workflows",

    "/notifications": "Notifications",
    "/calendar": "Calendar",
    "/profile": "Profile",
    "/settings": "Settings",
  };

  return map[pathname] ?? "Dashboard";
}

export default function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();

  const currentPageName = useMemo(() => getPageKeyFromPath(pathname || "/dashboard"), [pathname]);

  const [ready, setReady] = useState(false);

  useEffect(() => {
    let mounted = true;

    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!mounted) return;

      if (!data.session) {
        router.push("/login");
        return;
      }

      setReady(true);
    })();

    return () => {
      mounted = false;
    };
  }, [router]);

  if (!ready) {
    // Loader minimal (évite un flash de contenu avant redirect)
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-slate-50">
        <div className="tp-glass rounded-2xl px-6 py-4 shadow-lg">
          <div className="gradient-text text-lg font-semibold">TalentPilot AI</div>
          <div className="text-sm text-slate-600 mt-1">Chargement…</div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen bg-slate-50 flex flex-col">
      <AppHeader />
      <div className="hidden md:block">
        <SectionNav currentPageName={currentPageName} />
      </div>

      <main className="w-full md:w-[92%] mx-auto px-4 sm:px-6 py-8 pb-24 md:pb-8 flex-1 overflow-y-auto">
        {children}
      </main>

      <MobileNav currentPageName={currentPageName} />
      <AiQuickActions />
      <SupportChatbot />
    </div>
  );
}
