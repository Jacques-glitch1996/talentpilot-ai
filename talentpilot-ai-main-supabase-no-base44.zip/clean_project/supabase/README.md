# Supabase – Setup rapide

## 1) Base de données
1. Supabase → **SQL Editor**
2. Exécuter `schema.sql`

## 2) Storage
Créer un bucket : `documents`
- Public: OFF (recommandé)

### Policies Storage (simple, utilisateur propriétaire)
Dans Supabase → Storage → Policies, appliquer (exemples) :

- **SELECT** (lire)
  - condition: `auth.role() = 'authenticated'`
- **INSERT** (uploader)
  - condition: `auth.role() = 'authenticated'`

> Pour une sécurité stricte par chemin (ex: `org/<user_id>/...`), on peut ajouter des policies plus fines.

## 3) Variables d'environnement
Dans `.env.local` (local) et Vercel (prod):
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `ANTHROPIC_API_KEY` (si vous utilisez la génération IA)
