-- TalentPilot AI (Next.js) - Schéma minimal (Supabase)
-- Objectif: fournir les tables nécessaires à l'application (candidates, job_posts, interviews, documents, ai_logs).
-- IMPORTANT: ce schéma est générique et peut être ajusté selon vos besoins métier.

-- Extensions
create extension if not exists "pgcrypto";

-- Helpers
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Profiles (facultatif mais utile)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_set_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

-- Candidates
create table if not exists public.candidates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  first_name text not null default '',
  last_name text not null default '',
  email text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger candidates_set_updated_at
before update on public.candidates
for each row execute function public.set_updated_at();

-- Validations (optionnelles, mais cohérentes avec les messages d'erreur côté UI)
create or replace function public.candidates_validate()
returns trigger language plpgsql as $$
begin
  if (coalesce(new.email,'') = '' and coalesce(new.phone,'') = '') then
    raise exception 'candidates_email_or_phone_required';
  end if;
  if (coalesce(new.email,'') <> '' and position('@' in new.email) = 0) then
    raise exception 'candidates_email_format';
  end if;
  if (coalesce(new.phone,'') <> '' and length(regexp_replace(new.phone, '[^0-9]', '', 'g')) < 7) then
    raise exception 'candidates_phone_format';
  end if;
  return new;
end;
$$;

drop trigger if exists candidates_validate_trg on public.candidates;
create trigger candidates_validate_trg
before insert or update on public.candidates
for each row execute function public.candidates_validate();

-- Job posts
create table if not exists public.job_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  title text not null,
  description text not null,
  status text not null default 'open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger job_posts_set_updated_at
before update on public.job_posts
for each row execute function public.set_updated_at();

-- Interviews
create table if not exists public.interviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  candidate_id uuid not null references public.candidates(id) on delete cascade,
  job_post_id uuid not null references public.job_posts(id) on delete cascade,
  interview_date timestamptz,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger interviews_set_updated_at
before update on public.interviews
for each row execute function public.set_updated_at();

-- Documents
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  candidate_id uuid not null references public.candidates(id) on delete cascade,
  file_url text not null,
  file_type text not null default 'CV',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger documents_set_updated_at
before update on public.documents
for each row execute function public.set_updated_at();

-- AI logs
create table if not exists public.ai_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  type text not null,
  input text not null,
  output text not null,
  created_at timestamptz not null default now()
);

-- RLS
alter table public.profiles enable row level security;
alter table public.candidates enable row level security;
alter table public.job_posts enable row level security;
alter table public.interviews enable row level security;
alter table public.documents enable row level security;
alter table public.ai_logs enable row level security;

-- Policies: chaque utilisateur ne voit que ses lignes

drop policy if exists "profiles_own" on public.profiles;
create policy "profiles_own" on public.profiles
for all using (auth.uid() = id) with check (auth.uid() = id);

-- candidates
 drop policy if exists "candidates_own" on public.candidates;
 create policy "candidates_own" on public.candidates
 for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- job_posts
 drop policy if exists "job_posts_own" on public.job_posts;
 create policy "job_posts_own" on public.job_posts
 for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- interviews
 drop policy if exists "interviews_own" on public.interviews;
 create policy "interviews_own" on public.interviews
 for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- documents
 drop policy if exists "documents_own" on public.documents;
 create policy "documents_own" on public.documents
 for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ai_logs
 drop policy if exists "ai_logs_own" on public.ai_logs;
 create policy "ai_logs_own" on public.ai_logs
 for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Auto-create profile at signup (optionnel)
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
