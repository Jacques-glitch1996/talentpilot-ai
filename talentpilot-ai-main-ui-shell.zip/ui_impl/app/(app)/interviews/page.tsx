'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { PageHeader } from '@/components/app-shell/PageHeader';

type Interview = {
  id: string;
  candidate_id: string;
  job_post_id: string;
  interview_date: string | null;
  notes: string | null;
  created_at: string;
};

export default function InterviewsPage() {
  const router = useRouter();
  const [items, setItems] = useState<Interview[]>([]);
  const [candidateId, setCandidateId] = useState('');
  const [jobPostId, setJobPostId] = useState('');
  const [interviewDate, setInterviewDate] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');

  const refresh = async () => {
    setErr('');
    const { data, error } = await supabase
      .from('interviews')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      setErr(error.message);
      setItems([]);
      return;
    }
    setItems((data ?? []) as Interview[]);
  };

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        router.push('/login');
        return;
      }
      await refresh();
      setLoading(false);
    })();
  }, [router]);

  const addInterview = async () => {
    setErr('');
    if (!candidateId.trim() || !jobPostId.trim()) {
      setErr('Candidate ID et Job Post ID sont requis.');
      return;
    }

    const { error } = await supabase.from('interviews').insert({
      candidate_id: candidateId.trim(),
      job_post_id: jobPostId.trim(),
      interview_date: interviewDate ? new Date(interviewDate).toISOString() : null,
      notes: notes.trim() || null,
    });

    if (error) {
      setErr(error.message);
      return;
    }

    setCandidateId('');
    setJobPostId('');
    setInterviewDate('');
    setNotes('');
    await refresh();
  };

  return (
    <div>
      <PageHeader
        title="Entrevues"
        subtitle="Planification, suivi et notes d’entretien."
        right={
          <button onClick={addInterview} className="tp-btn tp-btn-primary">
            Ajouter
          </button>
        }
      />

      <div className="tp-grid">
        <div className="tp-card tp-col-4">
          <div style={{ fontWeight: 800, marginBottom: 10 }}>Nouvelle entrevue</div>
          <div style={{ display: 'grid', gap: 10 }}>
            <input className="tp-input" placeholder="Candidate ID" value={candidateId} onChange={(e) => setCandidateId(e.target.value)} />
            <input className="tp-input" placeholder="Job Post ID" value={jobPostId} onChange={(e) => setJobPostId(e.target.value)} />
            <input className="tp-input" type="datetime-local" value={interviewDate} onChange={(e) => setInterviewDate(e.target.value)} />
            <textarea className="tp-input" style={{ height: 110, paddingTop: 10, resize: 'vertical' }} placeholder="Notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
            <button onClick={addInterview} className="tp-btn tp-btn-primary">Ajouter</button>
            {err ? <div style={{ color: 'crimson', fontWeight: 800, fontSize: 13 }}>❌ {err}</div> : null}
          </div>
        </div>

        <div className="tp-card tp-col-8">
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
            <div style={{ fontWeight: 800 }}>Historique</div>
            <div className="tp-muted" style={{ fontSize: 12 }}>{loading ? 'Chargement…' : `${items.length} entretien(s)`}</div>
          </div>
          <div style={{ height: 10 }} />

          <div style={{ display: 'grid', gap: 10 }}>
            {items.map((it) => (
              <div key={it.id} className="tp-card" style={{ padding: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                  <div style={{ fontWeight: 800 }}>#{it.id.slice(0, 8)}</div>
                  <div className="tp-muted" style={{ fontSize: 12 }}>
                    {it.interview_date ? new Date(it.interview_date).toLocaleString('fr-CA') : '—'}
                  </div>
                </div>
                <div className="tp-muted" style={{ fontSize: 12, marginTop: 6 }}>
                  Candidate: {it.candidate_id} • Offre: {it.job_post_id}
                </div>
                {it.notes ? (
                  <div style={{ marginTop: 8, fontSize: 13, lineHeight: 1.5 }}>{it.notes}</div>
                ) : null}
              </div>
            ))}

            {!loading && items.length === 0 ? (
              <div className="tp-muted" style={{ fontSize: 13 }}>Aucune entrevue enregistrée.</div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
