'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { PageHeader } from '@/components/app-shell/PageHeader';

type AiLog = {
  id: string;
  type: string;
  input: string;
  output: string;
  created_at: string;
};

export default function HistoryPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [logs, setLogs] = useState<AiLog[]>([]);

  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [query, setQuery] = useState<string>('');
  const [limit, setLimit] = useState<number>(50);

  const refresh = async () => {
    setErr('');
    const { data, error } = await supabase
      .from('ai_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      setErr(error.message);
      setLogs([]);
      return;
    }

    setLogs((data ?? []) as AiLog[]);
  };

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        router.push('/login');
        return;
      }
      await refresh();
      setLoading(false);
    })();
  }, [router, limit]);

  const types = useMemo(() => {
    const set = new Set<string>();
    logs.forEach((l) => set.add(l.type || 'unknown'));
    return ['all', ...Array.from(set).sort((a, b) => a.localeCompare(b))];
  }, [logs]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return logs.filter((l) => {
      const okType = typeFilter === 'all' ? true : (l.type || '') === typeFilter;
      if (!okType) return false;
      if (!q) return true;
      const hay = `${l.type}\n${l.input}\n${l.output}`.toLowerCase();
      return hay.includes(q);
    });
  }, [logs, query, typeFilter]);

  return (
    <div>
      <PageHeader
        title="Historique"
        subtitle="Historique des générations IA et actions automatisées."
        right={
          <button onClick={refresh} className="tp-btn tp-btn-primary">
            Actualiser
          </button>
        }
      />

      <div className="tp-grid">
        <div className="tp-card tp-col-4">
          <div style={{ fontWeight: 800, marginBottom: 10 }}>Filtres</div>
          <div style={{ display: 'grid', gap: 10 }}>
            <select className="tp-input" value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
              {types.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <input className="tp-input" placeholder="Rechercher…" value={query} onChange={(e) => setQuery(e.target.value)} />
            <select className="tp-input" value={String(limit)} onChange={(e) => setLimit(Number(e.target.value))}>
              {[20, 50, 100, 200].map((n) => (
                <option key={n} value={n}>{n} derniers</option>
              ))}
            </select>
            {err ? <div style={{ color: 'crimson', fontWeight: 800, fontSize: 13 }}>❌ {err}</div> : null}
            <div className="tp-muted" style={{ fontSize: 12 }}>Affichage : {filtered.length} élément(s)</div>
          </div>
        </div>

        <div className="tp-card tp-col-8">
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
            <div style={{ fontWeight: 800 }}>Logs</div>
            <div className="tp-muted" style={{ fontSize: 12 }}>{loading ? 'Chargement…' : `${logs.length} total`}</div>
          </div>
          <div style={{ height: 10 }} />

          <div style={{ display: 'grid', gap: 10 }}>
            {filtered.map((l) => (
              <div key={l.id} className="tp-card" style={{ padding: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                  <div style={{ fontWeight: 800 }}>{l.type || 'unknown'}</div>
                  <div className="tp-muted" style={{ fontSize: 12 }}>{new Date(l.created_at).toLocaleString('fr-CA')}</div>
                </div>
                <div className="tp-muted" style={{ fontSize: 12, marginTop: 6 }}>Entrée</div>
                <div style={{ fontSize: 13, lineHeight: 1.5, whiteSpace: 'pre-wrap' }}>{(l.input || '').slice(0, 240)}{(l.input || '').length > 240 ? '…' : ''}</div>
                <div className="tp-muted" style={{ fontSize: 12, marginTop: 8 }}>Sortie</div>
                <div style={{ fontSize: 13, lineHeight: 1.5, whiteSpace: 'pre-wrap' }}>{(l.output || '').slice(0, 240)}{(l.output || '').length > 240 ? '…' : ''}</div>
              </div>
            ))}
            {!loading && filtered.length === 0 ? (
              <div className="tp-muted" style={{ fontSize: 13 }}>Aucun historique correspondant.</div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
