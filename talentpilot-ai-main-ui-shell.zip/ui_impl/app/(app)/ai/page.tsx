'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { PageHeader } from '@/components/app-shell/PageHeader';

export default function AIPage() {
  const router = useRouter();
  const [type, setType] = useState('job_description');
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) router.push('/login');
    })();
  }, [router]);

  const run = async () => {
    setErr('');
    setOutput('');
    setBusy(true);

    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;

    if (!token) {
      setBusy(false);
      router.push('/login');
      return;
    }

    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ type, input }),
      });

      const json = await res.json();
      setBusy(false);

      if (!res.ok) {
        setErr(json?.error ?? 'Erreur inconnue');
        return;
      }

      setOutput(json.output ?? '');
      if (json?.error) setErr(json.error);
    } catch (e: any) {
      setBusy(false);
      setErr(e?.message ?? 'Erreur réseau');
    }
  };

  return (
    <div>
      <PageHeader
        title="AI"
        subtitle="Génération de contenu (descriptions, messages, résumés, etc.)."
        right={
          <button onClick={run} className="tp-btn tp-btn-primary" disabled={busy}>
            {busy ? 'Génération…' : 'Générer'}
          </button>
        }
      />

      <div className="tp-grid">
        <div className="tp-card tp-col-4">
          <div style={{ fontWeight: 800, marginBottom: 10 }}>Type</div>
          <select className="tp-input" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="job_description">Job description</option>
            <option value="outreach">Message de prospection</option>
            <option value="summary">Résumé</option>
            <option value="screening">Questions de préqualification</option>
          </select>
          <div style={{ height: 10 }} />
          <div className="tp-muted" style={{ fontSize: 12 }}>
            Conseil : fournissez contexte + contraintes + ton.
          </div>
        </div>

        <div className="tp-card tp-col-8">
          <div style={{ fontWeight: 800, marginBottom: 10 }}>Entrée</div>
          <textarea
            className="tp-input"
            style={{ height: 180, paddingTop: 10, resize: 'vertical' }}
            placeholder="Collez ici la description, le contexte, ou les informations…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />

          {err ? (
            <div style={{ marginTop: 10, color: 'crimson', fontWeight: 800, fontSize: 13 }}>❌ {err}</div>
          ) : null}

          {output ? (
            <div className="tp-card" style={{ marginTop: 12 }}>
              <div style={{ fontWeight: 800, marginBottom: 8 }}>Sortie</div>
              <pre style={{ margin: 0, whiteSpace: 'pre-wrap', fontSize: 13, lineHeight: 1.5 }}>{output}</pre>
            </div>
          ) : (
            <div className="tp-muted" style={{ marginTop: 10, fontSize: 13 }}>
              La sortie apparaîtra ici.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
