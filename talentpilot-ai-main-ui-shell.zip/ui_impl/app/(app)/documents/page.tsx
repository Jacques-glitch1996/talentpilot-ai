'use client';

import { PageHeader } from '@/components/app-shell/PageHeader';

export default function Page() {
  const titleMap: Record<string, { title: string; subtitle: string }> = {
    messages: { title: 'Communication', subtitle: 'Messages, suivis et séquences.' },
    performance: { title: 'Performances', subtitle: 'Indicateurs et suivi de votre activité.' },
    documents: { title: 'Documents', subtitle: 'Génération et gestion de documents RH.' },
  };

  // Fallback : déduit le titre par l’URL via window.location (client-only)
  const key = typeof window !== 'undefined' ? window.location.pathname.split('/')[1] : '';
  const meta = titleMap[key] ?? { title: 'Page', subtitle: '' };

  return (
    <div>
      <PageHeader title={meta.title} subtitle={meta.subtitle} />
      <div className="tp-grid">
        <div className="tp-card tp-col-12">
          <div style={{ fontWeight: 800, marginBottom: 8 }}>Interface en cours d’alignement</div>
          <div className="tp-muted" style={{ fontSize: 13, lineHeight: 1.6 }}>
            Cette page utilise déjà votre backend Supabase. La priorité ici est de finaliser le rendu “pixel-perfect”
            (marges, cartes, typographie, composants). Une fois le style stabilisé, on reconnecte chaque section
            sur vos données existantes si nécessaire.
          </div>
        </div>
      </div>
    </div>
  );
}
