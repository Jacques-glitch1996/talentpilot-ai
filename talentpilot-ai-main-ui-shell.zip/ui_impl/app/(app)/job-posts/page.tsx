'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { PageHeader } from '@/components/app-shell/PageHeader';

type JobPost = {
  id: string;
  title: string;
  description: string;
  status: string;
};

export default function JobPostsPage() {
  const router = useRouter();
  const [jobs, setJobs] = useState<JobPost[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const { data: list } = await supabase
      .from('job_posts')
      .select('*')
      .order('created_at', { ascending: false });
    setJobs((list as JobPost[]) || []);
  };

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        router.push('/login');
        return;
      }
      await load();
      setLoading(false);
    })();
  }, [router]);

  const create = async () => {
    if (!title.trim()) return;
    await supabase.from('job_posts').insert({
      title: title.trim(),
      description: description.trim(),
      status: 'active',
    });
    setTitle('');
    setDescription('');
    await load();
  };

  return (
    <div>
      <PageHeader
        title="Offres"
        subtitle="Créez et gérez vos postes (job posts)."
        right={
          <button onClick={create} className="tp-btn tp-btn-primary">
            Créer
          </button>
        }
      />

      <div className="tp-grid">
        <div className="tp-card tp-col-4">
          <div style={{ fontWeight: 800, marginBottom: 10 }}>Nouvelle offre</div>
          <div style={{ display: 'grid', gap: 10 }}>
            <input className="tp-input" placeholder="Titre" value={title} onChange={(e) => setTitle(e.target.value)} />
            <textarea
              className="tp-input"
              style={{ height: 120, paddingTop: 10, resize: 'vertical' }}
              placeholder="Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <button onClick={create} className="tp-btn tp-btn-primary">Créer</button>
            <div className="tp-muted" style={{ fontSize: 12 }}>La description peut être enrichie par l’IA via l’onglet AI.</div>
          </div>
        </div>

        <div className="tp-card tp-col-8">
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
            <div style={{ fontWeight: 800 }}>Liste</div>
            <div className="tp-muted" style={{ fontSize: 12 }}>{loading ? 'Chargement…' : `${jobs.length} offre(s)`}</div>
          </div>
          <div style={{ height: 10 }} />

          <div style={{ display: 'grid', gap: 10 }}>
            {jobs.map((j) => (
              <div key={j.id} className="tp-card" style={{ padding: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                  <div>
                    <div style={{ fontWeight: 800 }}>{j.title}</div>
                    <div className="tp-muted" style={{ fontSize: 12, marginTop: 4 }}>
                      {j.description ? j.description.slice(0, 140) + (j.description.length > 140 ? '…' : '') : '—'}
                    </div>
                  </div>
                  <div className="tp-muted" style={{ fontSize: 12, fontWeight: 700 }}>{j.status}</div>
                </div>
              </div>
            ))}
            {(!loading && jobs.length === 0) ? (
              <div className="tp-muted" style={{ fontSize: 13 }}>Aucune offre pour le moment.</div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
