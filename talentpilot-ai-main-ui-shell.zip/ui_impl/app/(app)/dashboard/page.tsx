'use client';

import { PageHeader } from '@/components/app-shell/PageHeader';
import { useRequireAuth } from '@/lib/useRequireAuth';

export default function DashboardPage() {
  const { email, logout } = useRequireAuth();

  return (
    <div>
      <PageHeader
        title="Dashboard"
        subtitle="Aperçu général de votre activité de recrutement."
        right={
          <button onClick={logout} className="tp-btn tp-btn-primary">
            Déconnexion
          </button>
        }
      />

      <div className="tp-grid">
        <div className="tp-card tp-col-4">
          <div className="tp-muted" style={{ fontSize: 12 }}>Candidats</div>
          <div style={{ fontSize: 28, fontWeight: 800, marginTop: 6 }}>—</div>
          <div className="tp-muted" style={{ fontSize: 12, marginTop: 6 }}>Ce mois-ci</div>
        </div>
        <div className="tp-card tp-col-4">
          <div className="tp-muted" style={{ fontSize: 12 }}>Offres</div>
          <div style={{ fontSize: 28, fontWeight: 800, marginTop: 6 }}>—</div>
          <div className="tp-muted" style={{ fontSize: 12, marginTop: 6 }}>Actives</div>
        </div>
        <div className="tp-card tp-col-4">
          <div className="tp-muted" style={{ fontSize: 12 }}>Entrevues</div>
          <div style={{ fontSize: 28, fontWeight: 800, marginTop: 6 }}>—</div>
          <div className="tp-muted" style={{ fontSize: 12, marginTop: 6 }}>Planifiées</div>
        </div>

        <div className="tp-card tp-col-8">
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
            <div>
              <div style={{ fontWeight: 800 }}>Activité récente</div>
              <div className="tp-muted" style={{ fontSize: 12, marginTop: 4 }}>
                Connecté : <b>{email || '…'}</b>
              </div>
            </div>
            <div className="tp-muted" style={{ fontSize: 12 }}>Dernières 24h</div>
          </div>
          <div style={{ height: 10 }} />
          <div className="tp-muted" style={{ fontSize: 13 }}>
            Aucun événement à afficher pour le moment.
          </div>
        </div>

        <div className="tp-card tp-col-4">
          <div style={{ fontWeight: 800 }}>Raccourcis</div>
          <div style={{ height: 10 }} />
          <div style={{ display: 'grid', gap: 8 }}>
            <a className="tp-btn" href="/candidates" style={{ display: 'grid', placeItems: 'center', textDecoration: 'none', color: 'inherit' }}>
              Ajouter un candidat
            </a>
            <a className="tp-btn" href="/job-posts" style={{ display: 'grid', placeItems: 'center', textDecoration: 'none', color: 'inherit' }}>
              Créer une offre
            </a>
            <a className="tp-btn" href="/ai" style={{ display: 'grid', placeItems: 'center', textDecoration: 'none', color: 'inherit' }}>
              Demander à l’IA
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
