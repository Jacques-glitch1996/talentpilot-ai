'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { PageHeader } from '@/components/app-shell/PageHeader';

type Candidate = {
  id: string;
  first_name: string;
  last_name: string;
  email: string | null;
  phone: string | null;
};

export default function CandidatesPage() {
  const router = useRouter();
  const [list, setList] = useState<Candidate[]>([]);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        router.push('/login');
        return;
      }
      await load();
    })();
  }, [router]);

  const load = async () => {
    const { data, error } = await supabase
      .from('candidates')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) setList(data);
  };

  const add = async () => {
    setErrorMsg('');

    if (!email.trim() && !phone.trim()) {
      setErrorMsg('Un email ou un téléphone est requis.');
      return;
    }

    const { error } = await supabase.from('candidates').insert({
      first_name: firstName.trim(),
      last_name: lastName.trim(),
      email: email.trim() || null,
      phone: phone.trim() || null,
    });

    if (error) {
      if (error.message.includes('candidates_email_format')) setErrorMsg('Format email invalide.');
      else if (error.message.includes('candidates_phone_format')) setErrorMsg('Format téléphone invalide.');
      else if (error.message.includes('candidates_email_or_phone_required')) setErrorMsg('Un email ou un téléphone est requis.');
      else setErrorMsg(error.message);
      return;
    }

    setFirstName('');
    setLastName('');
    setEmail('');
    setPhone('');
    await load();
  };

  return (
    <div>
      <PageHeader
        title="Candidats"
        subtitle="Centralisez vos profils, coordonnées et documents."
        right={
          <button onClick={add} className="tp-btn tp-btn-primary">
            Ajouter
          </button>
        }
      />

      <div className="tp-grid">
        <div className="tp-card tp-col-4">
          <div style={{ fontWeight: 800, marginBottom: 10 }}>Nouveau candidat</div>
          <div style={{ display: 'grid', gap: 10 }}>
            <input className="tp-input" placeholder="Prénom" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
            <input className="tp-input" placeholder="Nom" value={lastName} onChange={(e) => setLastName(e.target.value)} />
            <input className="tp-input" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input className="tp-input" placeholder="Téléphone" value={phone} onChange={(e) => setPhone(e.target.value)} />

            {errorMsg ? (
              <div style={{ color: 'crimson', fontWeight: 700, fontSize: 13 }}>❌ {errorMsg}</div>
            ) : (
              <div className="tp-muted" style={{ fontSize: 12 }}>Astuce : email OU téléphone suffisent.</div>
            )}

            <button onClick={add} className="tp-btn tp-btn-primary">Ajouter</button>
          </div>
        </div>

        <div className="tp-card tp-col-8">
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
            <div style={{ fontWeight: 800 }}>Liste</div>
            <div className="tp-muted" style={{ fontSize: 12 }}>{list.length} candidat(s)</div>
          </div>

          <div style={{ height: 10 }} />

          <div style={{ display: 'grid', gap: 10 }}>
            {list.map((c) => (
              <div key={c.id} className="tp-card" style={{ padding: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                  <div style={{ fontWeight: 800 }}>
                    {c.first_name} {c.last_name}
                  </div>
                  <div className="tp-muted" style={{ fontSize: 12 }}>{c.email || c.phone || '—'}</div>
                </div>
              </div>
            ))}

            {list.length === 0 ? (
              <div className="tp-muted" style={{ fontSize: 13 }}>Aucun candidat pour le moment.</div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
